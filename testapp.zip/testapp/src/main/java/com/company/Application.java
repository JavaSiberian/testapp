package com.company;

import com.company.config.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.boot.context.embedded.*;
import org.springframework.boot.context.web.*;
import org.springframework.context.annotation.*;
import org.springframework.web.filter.*;

import java.util.*;

@SpringBootApplication
public class Application extends SpringBootServletInitializer {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(MvcConfiguration.class, args);
    }
/*
    @Bean
    public FilterRegistrationBean encodingFilter() {
        CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
        encodingFilter.setEncoding("UTF-8");
        encodingFilter.setForceEncoding(true);
        FilterRegistrationBean filterRegBean = new FilterRegistrationBean();
        filterRegBean.setUrlPatterns(getRootPathUrls());
        filterRegBean.setFilter(encodingFilter);
        filterRegBean.setOrder(1);
        return filterRegBean;
    }

    private List<String> getRootPathUrls() {
        List<String> urlPatterns = new ArrayList<>();
        urlPatterns.add("/");
        return urlPatterns;
    }*/
}
