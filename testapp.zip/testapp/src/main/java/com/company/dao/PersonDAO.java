package com.company.dao;

import com.company.model.Person;

import java.util.List;

public interface PersonDAO {
    void saveOrUpdate(Person person);

    void delete(int id);

    Person get(int id);

    List<Person> list();
}
