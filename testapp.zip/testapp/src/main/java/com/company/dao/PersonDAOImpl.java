package com.company.dao;

import javax.sql.DataSource;

import com.company.model.Person;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class PersonDAOImpl implements PersonDAO {

    private JdbcTemplate jdbcTemplate;

    public PersonDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void saveOrUpdate(Person person) {
        if (person.getId() == 0)
        { // insert
            String sql = "INSERT INTO people (name) VALUES (?)";
            jdbcTemplate.update(sql, person.getName());
        }
        else
        { // update
            String sql = "UPDATE people SET name=? WHERE id=?";
            jdbcTemplate.update(sql, person.getName(), person.getId());
        }
    }

    public void delete(int id) {
        String sql = "DELETE FROM people WHERE id=?";
        jdbcTemplate.update(sql, id);
    }

    public Person get(int id) {
        String sql = "SELECT * FROM people WHERE id=" + id;
        return jdbcTemplate.query(sql, rs -> {
            if (rs.next()) {
                Person contact = new Person();
                contact.setId(rs.getInt("contact_id"));
                contact.setName(rs.getString("name"));
                return contact;
            }
            return null;
        });
    }

    public List<Person> list() {
        String sql = "SELECT * FROM people";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Person person = new Person();
            person.setId(rs.getInt("id"));
            person.setName(rs.getString("name"));
            return person;
        });
    }
}
