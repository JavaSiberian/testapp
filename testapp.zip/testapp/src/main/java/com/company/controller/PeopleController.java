package com.company.controller;

import com.company.dao.*;
import com.company.model.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import java.io.*;
import java.util.*;

@Controller
public class PeopleController {
    @Autowired
    private PersonDAO personDAO;

    @RequestMapping(value="/index")
    public ModelAndView listContact(ModelAndView model) throws IOException {
        List<Person> listPeople = personDAO.list();
        model.addObject("listPeople", listPeople);
        model.setViewName("home");

        return model;
    }

    @RequestMapping(value = "people", method = RequestMethod.POST)
    public ModelAndView savePerson(@ModelAttribute Person person)
    {
        personDAO.saveOrUpdate(person);
        return new ModelAndView("redirect:/");
    }
}
